// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODOutputDevice.h"
#include <algorithm>
#if !PLATFORM_WIN
#include <unistd.h> // macOS usleep, clang
#endif

namespace AudioStreamOutputDevice
{
    // 7.1 - 384000 floats requested
    // some reserve
    std::map<FMOD::Sound*, RingBuffer<1000000>*> pcmbuffers;

    FMOD_RESULT F_CALLBACK pcmreadcallback(FMOD_SOUND* sound, void *data, unsigned int datalen)
    {
        float *fdata = (float*)data;
        auto length = datalen >> 2; // sizeof(float) == 4

        auto it = pcmbuffers.find((FMOD::Sound*)sound);
        if (it == pcmbuffers.end())
            return FMOD_OK;

        auto pcmbuffer = it->second;

        for (int n = 0; n < length; n++)
            pcmbuffer->Read(fdata[n]);

        return FMOD_OK;
    }

    FMOD_RESULT F_CALLBACK pcmsetposcallback(FMOD_SOUND* /*sound*/, int /*subsound*/, unsigned int /*position*/, FMOD_TIMEUNIT /*postype*/)
    {
        /*
        This is useful if the user calls Channel::setPosition and you want to seek your data accordingly.
        */
        return FMOD_OK;
    }


    class FMODOutputDevice;

    FMODOutputDevice::FMODOutputDevice(UInt32 outputDeviceID)
    {
        /*
        Create a System object and initialize.
        */
        result = FMOD::System_Create(&system);
        ERRCHECK(result);

        result = system->getVersion(&version);
        ERRCHECK(result);

        if (version < FMOD_VERSION)
        {
            Common_Fatal("FMOD lib version %08x doesn't match header version %08x", version, FMOD_VERSION);
        }

        // Windows PC: 1024 / 4
        // unsigned int dlenght;
        // int dcount;
        // system->getDSPBufferSize(&dlenght, &dcount);
        // ERRCHECK(result);

        // result = system->setDSPBufferSize(dspBLength, dspBCount);
        // ERRCHECK(result);
        
        result = system->init(2048, FMOD_INIT_NORMAL, NULL);
        ERRCHECK(result);
        
        result = system->setDriver(outputDeviceID);
        ERRCHECK(result);
    }

    FMODOutputDevice::~FMODOutputDevice()
    {
        if (!system)
            return;
        /*
        Shut down
        */
        // update the system before release to possibly not hang up on system close
        this->Update();

#if PLATFORM_OSX
        usleep(1000);
#else
        Sleep(100);
#endif

        // however, system close hang on macOC when quitting Editor when pPlayer is running anyway
        result = system->close();
        ERRCHECK(result);
        
        result = system->release();
        ERRCHECK(result);

        system = NULL;
    }

    void FMODOutputDevice::StartSound(FMOD::Sound **sound, UInt32 inchannels, UInt32 insamplerate)
    {
        // directly affects latency, can't be a second (insamplerate) long..
        auto decodebuffersize = 1024; // screw this and hardcode it on windows for now..  FastMax(insamplerate / 40.0f, 1024);
        
        /*
        Create and play the sound.
        */
        FMOD_CREATESOUNDEXINFO  exinfo;

        memset(&exinfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);                                         /* Required. */
        exinfo.numchannels = inchannels;                                                        /* Number of channels in the sound. */
        exinfo.defaultfrequency = insamplerate;                                                 /* Default playback rate of sound. */
                                                                                                // v this is directly latency related
        exinfo.decodebuffersize = decodebuffersize;                                             /* Chunk size of stream update in samples. This will be the amount of data passed to the user callback. */
        exinfo.length = exinfo.defaultfrequency * exinfo.numchannels * sizeof(float) * 5;           /* Length of PCM data in bytes of whole song (for Sound::getLength) */
        exinfo.format = FMOD_SOUND_FORMAT_PCMFLOAT;                                             /* Data format of sound. */
        exinfo.pcmreadcallback = pcmreadcallback;                                               /* User callback for reading. */
        exinfo.pcmsetposcallback = pcmsetposcallback;                                           /* User callback for seeking. */

       FMOD_MODE   mode = FMOD_OPENUSER | FMOD_LOOP_NORMAL | FMOD_CREATESTREAM;

        result = system->createSound(0, mode, &exinfo, sound);
        ERRCHECK(result);

        pcmbuffers[*sound] = new RingBuffer<1000000>();
        
        FMOD::Channel *channel;
        result = system->playSound(*sound, 0, 0, &channel);
        ERRCHECK(result);
        
        this->sounds_playing++;
    }

    void FMODOutputDevice::StopSound(FMOD::Sound **sound)
    {
        if (!*sound)
            return;
        
        result = (*sound)->release();
        ERRCHECK(result);

        this->Update();
        
         // stop calling callback ?
#if PLATFORM_OSX
        usleep(1000);
#else
        Sleep(100);
#endif
        this->Update();

        // delete buffer
        auto it = pcmbuffers.find(*sound);
        if (it != pcmbuffers.end())
        {
            delete it->second;
            pcmbuffers.erase(*sound);
        }

        this->sounds_playing--;

      *sound = NULL;
   }

    void FMODOutputDevice::Update()
    {
        result = system->update();
        ERRCHECK(result);
    }

    UInt32 FMODOutputDevice::Sounds()
    {
        return this->sounds_playing;
    }
}
