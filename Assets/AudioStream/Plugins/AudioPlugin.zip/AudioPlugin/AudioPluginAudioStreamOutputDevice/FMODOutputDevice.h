// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(_WIN64)
#include "..\AudioPluginUtil.h" // this has platforms abstractions apart from plugin convenience macros, maily
#include "..\AudioPluginInterface.h"
#else
#include "AudioPluginUtil.h"
#include "AudioPluginInterface.h" // Xcode added files are found
#endif
#include "fmod.hpp"
#include "fmod_common.h"
#include <list>
#include <map>

namespace AudioStreamOutputDevice
{
    class FMODOutputDevice
    {
    public:
        FMODOutputDevice(UInt32 outputDeviceID);
        ~FMODOutputDevice();

        void StartSound(FMOD::Sound **sound, UInt32 inchannels, UInt32 insamplerate);
        void StopSound(FMOD::Sound **sound);

        void Update();
        UInt32 Sounds();

    private:
        FMOD::System           *system = NULL;
        FMOD_RESULT             result;
        unsigned int            version;
        void                   *extradriverdata = 0;
        UInt32                  sounds_playing = 0;
    };
}
