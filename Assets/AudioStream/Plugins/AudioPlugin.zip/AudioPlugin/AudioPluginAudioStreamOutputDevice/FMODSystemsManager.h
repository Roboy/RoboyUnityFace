// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "Plugin_AudioStreamOutputDevice.h"
#include "FMODOutputDevice.h"

namespace AudioStreamOutputDevice
{
    void ProcessCallbackForDevice(EffectData *data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate);
    void StopSound(EffectData *data);
}
