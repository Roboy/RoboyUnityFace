// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "FMODOutputDevice.h"

namespace AudioStreamOutputDevice
{
    enum Param
    {
        P_OUTPUTDEVICEID
        , P_PASSTHRU
        // , P_DSPBUFFERLENGTH
        // , P_DSPBUFFERCOUNT
        , P_NUM
    };

    struct EffectData
    {
        float parameters[P_NUM];
        FMODOutputDevice *system;   // FMOD system created for this plugin instance
        FMOD::Sound *sound;         // FMOD sound created for this plugin instance and system
    };
}
