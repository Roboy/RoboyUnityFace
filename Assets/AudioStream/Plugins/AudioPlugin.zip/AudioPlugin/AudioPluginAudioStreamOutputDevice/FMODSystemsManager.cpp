// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODSystemsManager.h"
#include <map>

namespace AudioStreamOutputDevice
{
    // Output - FMOD Systems
    std::map<UInt32, FMODOutputDevice*> systems;
    extern std::map<FMOD::Sound*, RingBuffer<1000000>*> pcmbuffers;
    Mutex mMutex;   // pcmbuffers sync feed/stop

    void ProcessCallbackForDevice(EffectData *data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate)
    {
        MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        auto system = systems.find(outputDeviceID);
        if (system == systems.end())
        {
            systems[outputDeviceID] = new FMODOutputDevice(outputDeviceID);
            data->system = systems[outputDeviceID];
        }

        if (data->sound == NULL)
            systems[outputDeviceID]->StartSound(&data->sound, inchannels, samplerate);

        systems[outputDeviceID]->Update();

        // forward the inbuffer
        auto pcmbuffer = pcmbuffers[data->sound];

        for (unsigned int n = 0; n < length * inchannels; n++)
            pcmbuffer->Feed(inbuffer[n]);
    }

    void StopSound(EffectData *data)
    {
        MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        auto system = systems.find(outputDeviceID);
        if (system != systems.end())
        {
            system->second->StopSound(&data->sound);
            
            /*
             proabbly can leave FMOD system around for the lifetime of process
             
            // stopped
            if (data->sound == NULL)
            {
                // if # of sounds == 0 per output, release FMOD
                auto sounds = system->second->Sounds();
                if (sounds < 1)
                {
                    delete system->second;
                    systems.erase(system->first);
                    data->system = NULL;
                }
            }
             */
        }
    }
}
