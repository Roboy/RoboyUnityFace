// (c) 2016-2019 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

DECLARE_EFFECT("AudioStream OutputDevice", AudioStreamOutputDevice)
